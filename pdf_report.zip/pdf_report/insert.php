<?php	
	include("connection.php");
	$NM=$_REQUEST["nm"];
	$ag=$_REQUEST["age"];
	$mail=$_REQUEST["eml"];
	
	$serverName = "localhost";
	$userName = "root";
	$password = "";
	$dbName = "tut";
	
	$conn = new mysqli($serverName,$userName,$password,$dbName);
	
	$sql = "insert into pdf_export (name,age,email) values('$NM','$ag','$mail')";

	if(mysqli_query($conn, $sql))
	{
		echo "New record created successfully";
		header('Location:index.php');
	}
	else 
	{
    	echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
	?>